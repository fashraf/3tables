/**
 * Theme: Dastone - Responsive Bootstrap 5 Admin Dashboard
 * Author: Mannatthemes
 * Validation Js
 */


$(document).ready(function() {
    $('.form-parsley').parsley();
});