﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class UserDetail : System.Web.UI.Page
    {
        AppCode.Drop drop = new AppCode.Drop();
        AppCode.Repository repo = new AppCode.Repository();
        AppCode.Ts t = new AppCode.Ts();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                int UserId = Convert.ToInt32(Request.QueryString["Id"]);
                LoadPatientInfo(UserId);
                DataTable getUserStatus = drop.GetUserStatus();
                drop.FillDropDownList(UserSatusDrop, getUserStatus, "Status", "Id");


            }
        }

        private void LoadPatientInfo(int UserId)
        {
            
            DataTable dt = repo.geUserDetail(UserId);
            //NationalIdTxt.Text = dt.Rows[0]["UserId"].ToString();
            TitleNameLbl.Text = dt.Rows[0]["UserTitle"].ToString() +" "+ dt.Rows[0]["UserFullName"].ToString();
            MobileLbl.Text = dt.Rows[0]["Mobile"].ToString();
            EmailLbl.Text = dt.Rows[0]["Email"].ToString();
            InstituteLbl.Text = dt.Rows[0]["InstituteName"].ToString();
            CityLbl.Text = dt.Rows[0]["City"].ToString();
            OwnershipLbl.Text = dt.Rows[0]["Ownership"].ToString();
            UserSatusDrop.Text = dt.Rows[0]["UserAccStatus"].ToString();

            string dtleft = t.GetElapsedTime(Convert.ToDateTime(dt.Rows[0]["CreatedDt"]));
            CreatedDtLbl.Text = Convert.ToDateTime(dt.Rows[0]["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt") + " (" + dtleft + " )";
        }

        protected void Confirm_Btn_Click(object sender, EventArgs e)
        {
            Confirm_Header_Lbl.Text = "Confirm !";
            Confirm_Middle_Lbl.Text = "Are you sure you want to <strong>"+UserSatusDrop.SelectedItem.Text+ "</strong> this User ?";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
            UpdatePanel2.Update();
        }

        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            int UserId = Convert.ToInt32(Request.QueryString["Id"]);
            string UpdatedUserName = "Fahad Ashraf";
            int UserStatus = Convert.ToInt32(UserSatusDrop.SelectedValue);
            bool UpdateUserInfo = repo.UpdateUserInfo(UserId, UserStatus, UpdatedUserName);
            string toastmsg = "";
            if (UpdateUserInfo==true)
            {
                 toastmsg = "User Activated Successfully.";
                //ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast()", true);
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('"+ toastmsg + "')", true);
                string FullName = TitleNameLbl.Text;
                string Email = EmailLbl.Text.Trim();
                if (UserSatusDrop.SelectedValue == "10")
                {
                    string Page = "../emiltemp/approve.html";
                    string EmailSubject = "Account Activated Successfully.[Novo Genomics]";
                    string msg = "Account Activated Sucessfully.";
                    AppCode.sEmail.SendEmail(FullName, Email, EmailSubject, Page, msg);

                }
                else if (UserSatusDrop.SelectedValue == "11")
                {
                     toastmsg = "User Disapproved";
                    string Page = "../emiltemp/disapprove.html";
                    string EmailSubject = "Account Not-Approved.[Novo Genomics]";
                    string msg = "Account Not Approved.";
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + toastmsg + "')", true);
                    AppCode.sEmail.SendEmail(FullName, Email, EmailSubject, Page, msg);

                }
                else
                {
                }
                
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

        }
    }
}