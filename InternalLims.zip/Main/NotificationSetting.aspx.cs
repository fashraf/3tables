﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class NotificationSetting : System.Web.UI.Page
    {
        AppCode.Connection Con = new AppCode.Connection();
        DataTable results = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["ID"] != null)
            //{
            if (IsPostBack == false)
            {
                int EmpId = 1; //Convert.ToInt32(Session["ID"]);
                LoadSetting(EmpId);
            }
            //}
            //else
            //{
            //    Response.Redirect("../Login.aspx");
            //}
        }


        private void LoadSetting(int EmpId)
        {
            String Connection = Con.NovoAdmin();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT Serial,case when EmpEmailMaster.EmpId is null then 0 else 1 end hasaccess,NotificationDesc FROM EmpEmailMaster left JOIN EmpMaster ON EmpEmailMaster.EmpId = EmpMaster.EmpSerno right JOIN NotiTypeMaster ON EmpEmailMaster.NotificationType = NotiTypeMaster.Serial and (EmpEmailMaster.EmpId =@userid)", con);
            command.CommandType = CommandType.Text;
            command.Parameters.Add(new SqlParameter("@userid", EmpId));
            SqlDataAdapter da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            NotiRpt.DataSource = dt;
            NotiRpt.DataBind();
            command.Dispose();
            con.Close();
            con.Dispose();
        }
        protected void Confirm_Btn_Click(object sender, EventArgs e)
        {
            Confirm_Header_Lbl.Text = "Confirm !";
            Confirm_Middle_Lbl.Text = "Are you sure you want to update your  Setting ?";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
            Submit_Btn.Visible = true;
            UpdatePanel2.Update();
        }

        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            UpdateSettng(1);
            //if (Session["ID"] != null)
            //{
            //    int hid = Convert.ToInt32(Session["ID"]);
            //    UpdateDemographicData(hid);

            //    string Name = Session["Name"].ToString();
            //    string HospitalName = Session["HospitalName"].ToString();
            //    int UID = Convert.ToInt32(Session["UID"].ToString());
            //    int HID = Convert.ToInt32(Session["ID"].ToString());
            //    string meta = Name + " Update Staff Category of " + HospitalName;
            //    //Insert ai = new Insert();
            //    //ai.auditlog(HID, UID, Name, 4, meta, 1, true);
            //}
            //else
            //{
            //    Response.Redirect("../Login.aspx");
            //}
        }
        private void UpdateSettng(int EmpId)
        {
            delpreviousstaffcat(EmpId);
            foreach (RepeaterItem item in NotiRpt.Items)
            {
                if (((CheckBox)item.FindControl("IdCheckBox")).Checked == true)
                {

                    int NotiControlId = Convert.ToInt32(((Label)item.FindControl("NotiControlId")).Text);
                    UpdateEmpNoti(EmpId, NotiControlId, 1);

                }
            }

            //int ID = Convert.ToInt32(Session["ID"]);
            //string Name = Session["Name"].ToString();
            //insert.Log(ID, 3, Name);
        }

        private void delpreviousstaffcat(int EmpId)
        {
            String Connection = Con.NovoAdmin();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string Insert = "delete from EmpEmailMaster where EmpId=@EmpId";
            SqlCommand insert = null;
            insert = new SqlCommand(Insert, con);
            insert.CommandType = CommandType.Text;
            insert.Parameters.Add("@EmpId", EmpId);
            if (insert.ExecuteNonQuery() > 0)
            {
                //display = "staff Category Updated !";
                //DisplayToastr(display, toastrTypes.Success.ToString());

                //ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "redirectJS", "setTimeout(function() { window.location.replace('HospitalInfoPage.aspx') }, 3500);", true);
                //LoadDemoGraphicData(477);
            }
            insert.Dispose();
            con.Close();
            con.Dispose();
        }

        private void UpdateEmpNoti(int EmpId, int NotificationType, int Email)
        {
            String Connection = Con.NovoAdmin();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            //string Name = Session["Name"].ToString();
            string Insert = "insert into EmpEmailMaster(EmpId,NotificationType,Email) values (@EmpId,@NotificationType,@Email)";
            SqlCommand insertcmd = null;
            insertcmd = new SqlCommand(Insert, con);
            insertcmd.CommandType = CommandType.Text;
            insertcmd.Parameters.Add("@EmpId", EmpId);
            insertcmd.Parameters.Add("@NotificationType", NotificationType);
            insertcmd.Parameters.Add("@Email", Email);
            if (insertcmd.ExecuteNonQuery() > 0)
            {
               string display = "Settings Updated Successfully!";
                //DisplayToastr(display, toastrTypes.Success.ToString());

                UpdateSettng(EmpId);
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + display + "')", true);
                //ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "redirectJS", "setTimeout(function() { window.location.replace('HospitalInfoPage.aspx') }, 3500);", true);
                //string Name = Session["Name"].ToString();
                //insert.Log(hid, 4, Name);
            }
            insertcmd.Dispose();
            con.Close();
            con.Dispose();
        }

        protected void NotoRpt_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                CheckBox lblDate = (CheckBox)e.Item.FindControl("IdCheckBox");
                HtmlGenericControl video = e.Item.FindControl("div_id") as HtmlGenericControl;

                if (lblDate.Checked == true)
                {
                    video.Attributes["class"] = "alert alert-success";
                }
                else
                {
                    video.Attributes["class"] = "alert alert-info";
                }
            }
        }
    }
}