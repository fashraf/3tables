﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class ReceiveTestDetail : System.Web.UI.Page
    {
        AppCode.Repository repo = new AppCode.Repository();
        AppCode.Drop drop = new AppCode.Drop();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                int TestSerno = Convert.ToInt32(Request.QueryString["Id"]);
                LoadTestInfo(TestSerno);
                //RejectionVal.Enabled = false;
            }
        }

        private void LoadTestInfo(int TestSerno)
        {
            Status_Grid.DataSource = repo.GetTestAutoWorkFlowStatus(TestSerno);
            Status_Grid.DataBind();

            DataTable dt = repo.getNiptDetailById(TestSerno);
            txtBarCode.Text = dt.Rows[0]["BarcodeId"].ToString();
            TestLbl.Text = dt.Rows[0]["TestName"].ToString() + ">" + dt.Rows[0]["SubTestName"].ToString();
            txtNationalID.Text = dt.Rows[0]["NationalId"].ToString();
            txtPatientMRN.Text = dt.Rows[0]["PatientMRN"].ToString();
            txtName.Text = dt.Rows[0]["Name"].ToString();
            CreatedLbl.Text = Convert.ToDateTime(dt.Rows[0]["CreatedDt"]).ToString("dd.MMMM.yyyy hh:mm tt");

            DobTxt.Text = Convert.ToDateTime(dt.Rows[0]["Dob"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["DobYears"].ToString() + " ) Year/s";
            txtMobile.Text = dt.Rows[0]["Mobile"].ToString();
            CityLbl.Text = dt.Rows[0]["City"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            txtAddress.Text = dt.Rows[0]["Address"].ToString();
            EthnicLbl.Text = dt.Rows[0]["EthnicBackground"].ToString();

            MenstrualPeriodTxt.Text = Convert.ToDateTime(dt.Rows[0]["LastMenstrualPeriodDate"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["LastMenstrualPeriodWeeks"].ToString() + " ) week/s";
            txtAgeOfGestation.Text = dt.Rows[0]["AgeofGestation"].ToString();

            txtMaternalWeight.Text = dt.Rows[0]["MaternalWeight"].ToString();
            MarriageConsanguineousLbl.Text = dt.Rows[0]["MarriageCon"].ToString();
            ModeConceptionLbl.Text = dt.Rows[0]["ModeConception"].ToString();

            HistoryGeneticTestingLbl.Text = dt.Rows[0]["HistoryGenetic"].ToString();
            LatestUltrasoundTxt.Text = Convert.ToDateTime(dt.Rows[0]["LatestUltrasound"]).ToString("dd.MMMM.yyyy");
            txtUltrasoundFindings.Text = dt.Rows[0]["Ultrasoundfindings"].ToString();
            txtFurtherClinicalDetails.Text = dt.Rows[0]["FurtherClinicalDetails"].ToString();


            txtRequestorName.Text = dt.Rows[0]["RequesterName"].ToString();
            txtRequstorEmail.Text = dt.Rows[0]["RequesterEmail"].ToString();
            txtRequestorMobile.Text = dt.Rows[0]["RequesterMobile"].ToString();

            InstituteLbl.Value= dt.Rows[0]["HID"].ToString();
            StatusRibbon.Text = dt.Rows[0]["TestStatus"].ToString();
            int statusid = Convert.ToInt32(dt.Rows[0]["StatusID"].ToString());
            if(statusid==3)
            {
                Cancle_Lnk.Visible = true;
            }
            else
            {
                Cancle_Lnk.Visible = false;
            }

            StatusRibbon.Text = dt.Rows[0]["TestStatus"].ToString();

            if (StatusRibbon.Text == "Cancled")
            {
                StatusRibbon.CssClass = "alert alert-danger border";
            }
            else
            {
                StatusRibbon.CssClass = "alert alert-primary border";
            }

            DataTable Imgdt = repo.geTestAttachment(TestSerno);
            Img_Grid.DataSource = Imgdt;
            Img_Grid.DataBind();
        }

        protected void Confrim_Btn_Click(object sender, EventArgs e)
        {
            //Confirm_Header_Lbl.Text = "Confirm !";
            //Confirm_Middle_Lbl.Text = "Are you sure you want to <strong>" + StatusDrop.SelectedItem.Text + "</strong> this Test Request ?";
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
            //UpdatePanel2.Update();
        }

        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            string barcode = txtBarCode.Text;
            int TestSerno = Convert.ToInt32(Request.QueryString["Id"]);
            string UpdatedUserName = "Fahad Ashraf";
            //int UserStatus = Convert.ToInt32(StatusDrop.SelectedValue);
            //int StatusId = Convert.ToInt32(StatusDrop.SelectedValue);
            //int rejectreason = 0;
            //if (StatusId == 1009)
            //{
            //    rejectreason = Convert.ToInt32(RejectionReasonDrop.SelectedValue);
            //}
            //else
            //{
            //    rejectreason = 0;
            //}
            int UserStatus = Convert.ToInt32(Status_hdn.Value);
            int StatusId = Convert.ToInt32(Status_hdn.Value);

            bool UpdateUserInfo = repo.UpdateTestRequestStatus(TestSerno, UserStatus, 0, UpdatedUserName);

            repo.InsertTimelineForTest(TestSerno, StatusId, UpdatedUserName, "", "");
            string toastmsg = "";
            if (UpdateUserInfo == true)
            {

                string Email = "fhd.ashraf@gmail.com";// EmailLbl.Text.Trim();

                toastmsg = "Test Request Approved.";
                string Page = "../emiltemp/ReceiveTestEmail.html";
                string EmailSubject = "NIPT -" + barcode;
                string msg = "NIPT Request with barcode -" + txtBarCode.Text + " test Request is Approved and Send to the Lab.";
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + toastmsg + "')", true);
                AppCode.sEmail.SendEmail("User", Email, EmailSubject, Page, msg);


                string novomsg = "NIPT Request with Barcode  </br><strong>" + barcode + "</strong>  is Approved and Send to the Lab.";
                string Institute = InstituteLbl.Value;
                AppCode.SNotiNovo.SendNotiToNovo(2, barcode, novomsg);

                int InstituteId = Convert.ToInt32(InstituteLbl.Value);
                AppCode.notification.SaveNotification(InstituteId, 0, 3, msg, true);
            }
            else
            {

            }
            LoadTestInfo(TestSerno);
        }

        protected void Img_Grid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
            Response.TransmitFile(Server.MapPath(e.CommandArgument.ToString()));
            Response.End();
        }

        protected void Status_Grid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Status_hdn.Value = "";
            Status_Name.Value = "";
            if (e.CommandName == "Status")
            {
                GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                string Status = (row.FindControl("Status_Lnk") as Button).Text;
                string statusid = (row.FindControl("status_lbl") as Label).Text;
                Status_hdn.Value = statusid;
                Status_Name.Value = Status;
                Confirm_Header_Lbl.Text = "Confirm !";
                Confirm_Middle_Lbl.Text = "Are you sure you want to Change the Status to </br><strong>" + Status + "</strong></br> for this NIPT Test ?";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
                UpdatePanel2.Update();
            }
        }

        protected void Cancle_Lnk_Click(object sender, EventArgs e)
        {
            string Id = Request.QueryString["Id"];
            Response.Redirect("CancelTest.aspx?Id=" + Id + "");
        }
    }
}