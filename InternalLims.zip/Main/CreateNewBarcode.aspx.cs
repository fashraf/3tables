﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using static InternalLims.AppCode.dto;

namespace InternalLims.Main
{
    public partial class CreateNewBarcode : System.Web.UI.Page
    {
        AppCode.Drop drop = new AppCode.Drop();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                LoadData();
            }
        }

        private void LoadData()
        {
            TestDrop.DataSource = drop.GetTestList();
            TestDrop.DataBind();
            DataTable gettestlist = drop.GetTestList();
            drop.FillDropDownList(TestDrop, gettestlist, "TestName", "Id");
        }
        protected void TestDrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            int TestId = Convert.ToInt32(TestDrop.SelectedValue);
            DataTable getsubtest = drop.GetSubTestList(TestId);
            drop.FillDropDownList(SubTestDrop, getsubtest, "SubTestName", "Id");
            string jsFunc = " bindPrinters()";
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn", jsFunc, true);
        }

        protected void Confirm_Btn_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
            UpdatePanel2.Update();
            Submit_Btn.Visible = true;
            ModalTestLbl.Text = TestDrop.SelectedItem.Text;
            ModalSubTestLbl.Text = SubTestDrop.SelectedItem.Text;
            if (InstituteDrop.SelectedItem != null && InstituteDrop.SelectedItem.Text == "------")
            {
                location.Visible = false;
                ModalInstituteLbl.Visible = false;
            }
            else
            {
                ModalInstituteLbl.Text = InstituteDrop.SelectedItem.Text;
            }
            Total_Lbl.Text = TotalTxt.Text;
            Button2.Text = "Close";
        }

        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            try
            {
                int testid = Convert.ToInt32(TestDrop.SelectedValue);
                int subtestid = Convert.ToInt32(SubTestDrop.SelectedValue);
                int TypeId = Convert.ToInt32(TypeDrop.SelectedValue);
                int instituteid = Convert.ToInt32(InstituteDrop.SelectedValue);
                int Total = Convert.ToInt32(TotalTxt.Text);

                AppCode.Connection Con = new AppCode.Connection();
                String Connection = Con.Con();
                SqlConnection con = new SqlConnection(Connection);
                con.Open();
                SqlCommand command = new SqlCommand("Insert into TestMasterT(TestId,SubTestId,TypeId,InstituteId,PatientId,CreatedDt,CreatedBy,ReceiveDt) values (@TestId,@SubTestId,@TypeId,@InstituteId,@PatientId,getdate(),@CreatedBy,getdate()+5);Select Scope_Identity();", con);
                command.CommandType = System.Data.CommandType.Text;
                command.Parameters.Add(new SqlParameter("@TestId ", testid));
                command.Parameters.Add(new SqlParameter("@SubTestId", subtestid));
                command.Parameters.Add(new SqlParameter("@TypeId", TypeId));
                if (TypeId == 1)
                {
                    command.Parameters.Add(new SqlParameter("@InstituteId", instituteid));
                    command.Parameters.Add(new SqlParameter("@PatientId", DBNull.Value));
                }
                else if (TypeId == 2)
                {
                    command.Parameters.Add(new SqlParameter("@InstituteId", DBNull.Value));
                    command.Parameters.Add(new SqlParameter("@PatientId", instituteid));
                }
                else if (TypeId == 3)
                {
                    command.Parameters.Add(new SqlParameter("@InstituteId", DBNull.Value));
                    command.Parameters.Add(new SqlParameter("@PatientId", DBNull.Value));
                }

                command.Parameters.Add(new SqlParameter("@CreatedBy", "Fahad Ashraf"));
                //command.Parameters.Add(new SqlParameter("@CreatedDt", DateTime.Now.ToString()));
                var values = "";
                for (int i = 0; i < Total; i++)
                {
                    int CompletedTestId = Convert.ToInt32(command.ExecuteScalar());
                    if (CompletedTestId > 0)
                        values = values == "" ? CompletedTestId.ToString() : values + "," + CompletedTestId.ToString();
                }
                command = new SqlCommand();
                string query = "select * from TestMasterT where TestSerno in(" + values + ")";
                command = new SqlCommand(query, con);

                List<TestMasterT> barcodeWithRelatedData = new List<TestMasterT>();

                using (command = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            TestMasterT testMasterT = new TestMasterT();
                            testMasterT.BID = reader["BID"].ToString();
                            testMasterT.TestSerno = Convert.ToInt32(reader["TestSerno"]);
                            testMasterT.CreatedBy = reader["CreatedBy"].ToString();
                            testMasterT.TestId = Convert.ToInt32(reader["TestId"]);
                            testMasterT.CreatedDt = (DateTime)reader["CreatedDt"];
                            var rec = reader["ReceiveDt"];
                            testMasterT.ReceiveDt = (DateTime)reader["ReceiveDt"];
                            barcodeWithRelatedData.Add(testMasterT);
                        }
                    }
                }

                con.Dispose();
                con.Close();
                con.Dispose();
                //ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn4", "alert('Data Saved Succeessfully')", true);

                string msg= "Barcode Created Succeessfully";
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + msg + "')", true);


                var result = JsonConvert.SerializeObject(barcodeWithRelatedData);
                string jsFunc = "bindBarcode( '" + result + "')";
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn", jsFunc, true);

            }
            catch (Exception ex)
            {
                string jsFunc = "Alert( '" + ex.Message.ToString() + "')";
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "error", jsFunc, true);
            }
        }
        protected void TypeDrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (TypeDrop.SelectedValue == "1")
            {
                InstituteDrop.Enabled = true;
                DataTable getdata = drop.GetInstituteList();
                drop.FillDropDownList(InstituteDrop, getdata, "Name", "Id");
                TotalTxt.Text = string.Empty;
                TotalTxt.Enabled = true;
            }
            else if (TypeDrop.SelectedValue == "2")
            {
                InstituteDrop.Enabled = true;
                DataTable getdata = drop.GetPatientList();
                drop.FillDropDownList(InstituteDrop, getdata, "Name", "Id");
                TotalTxt.Text = "1";
                TotalTxt.Enabled = false;
            }
            else if (TypeDrop.SelectedValue == "3")
            {
                InstituteDrop.SelectedValue = "-1";
                InstituteDrop.Enabled = false;
                TotalTxt.Text = string.Empty;
                TotalTxt.Enabled = true;
            }
            string jsFunc = " bindPrinters()";
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn", jsFunc, true);
        }


        [WebMethod]
        //public static string AddLogs()
        public static void AddLogs(List<BarCodeLogs> barCodeLogs)
        {
            AppCode.Connection Con = new AppCode.Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();

            barCodeLogs.ForEach(log =>
            {
                try
                {
                    SqlCommand command = new SqlCommand("Insert into BarCodeLogs(TestSemo,BID,ErrorMessage,IPAddress) values (@TestSemo,@BID,@ErrorMessage,@IPAddress);", con);
                    command.CommandType = System.Data.CommandType.Text;
                    command.Parameters.Add(new SqlParameter("@TestSemo", log.TestSemo));
                    command.Parameters.Add(new SqlParameter("@BID", log.BID));
                    command.Parameters.Add(new SqlParameter("@ErrorMessage", log.ErrorMesssage));
                    command.Parameters.Add(new SqlParameter("@IPAddress", log.IPAddress));
                    command.ExecuteScalar();
                }
                catch (Exception ex)
                {


                }
            });
            con.Dispose();
            con.Close();
            con.Dispose();
        }

    }
}