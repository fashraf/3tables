﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class NIPTListTaT : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                ListLoad();
            }
        }

        private void ListLoad()
        {
            AppCode.Connection Con = new AppCode.Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = new SqlCommand("NIPTTestListWithTAT", con);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            NiptList_Grid.DataSource = results;
            NiptList_Grid.DataBind();

        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            NiptList_Grid.PageIndex = e.NewPageIndex;
            ListLoad();
        }
    }
}