﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static InternalLims.AppCode.dto;

namespace InternalLims.Main
{
    public partial class TestKitRequestView : System.Web.UI.Page
    {
        AppCode.Repository repo = new AppCode.Repository();
        AppCode.KitRequestBarcode barcode = new AppCode.KitRequestBarcode();
        protected void Page_Load(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(Request.QueryString["Id"]);
            if (IsPostBack == false)
            {
                LoadInstituteDetail(Id);
            }
        }

        private void LoadInstituteDetail(int Id)
        {
            DataTable dt = repo.getTestKitRequest(Id);
            InstituteHidden.Value= dt.Rows[0]["InstituteId"].ToString();
            InstituteDrp.Text = dt.Rows[0]["InstituteName"].ToString();
            CityTxt.Text = dt.Rows[0]["City"].ToString();
            StatusTxt.Text = dt.Rows[0]["TestStatus"].ToString();
            TestHidden.Value= dt.Rows[0]["TestId"].ToString();
            Testtxt.Text = dt.Rows[0]["TestName"].ToString();

            SubTestHidden.Value = dt.Rows[0]["SubTestMasterSerno"].ToString();
            SubTesttxt.Text = dt.Rows[0]["SubTestName"].ToString();

            TestRequestTxt.Text = dt.Rows[0]["TestRequest"].ToString();
            ActualTestTxt.Text = dt.Rows[0]["TestRequest"].ToString();

            DtTxt.Text = dt.Rows[0]["CreatedDt"].ToString();
        }

        public void Submit_Btn_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(Request.QueryString["Id"]);

                int testid = Convert.ToInt32(TestHidden.Value);
                int subtestid = Convert.ToInt32(SubTestHidden.Value);
                int TypeId = Convert.ToInt32(1);
                int instituteid = Convert.ToInt32(InstituteHidden.Value);
                int Total = Convert.ToInt32(ActualTestTxt.Text);
                string CreatedBy = "Fahad";

                string submitbarcode = barcode.CreateBarcodeReqest(Id, testid, subtestid, TypeId, instituteid, Total, CreatedBy);
                if (submitbarcode == "1")
                {
                    GetPrintBarcode(Id);
                }
                else
                {
                }
                

                //AppCode.Connection Con = new AppCode.Connection();
                //String Connection = Con.Con();
                //SqlConnection con = new SqlConnection(Connection);
                //con.Open();
                ////SqlCommand command = new SqlCommand("update TestMasterT set RequestStatus=@RequestStatus where TestReqSerno=@Id", con);
                ////command.CommandType = System.Data.CommandType.Text;

                ////command.Parameters.Add(new SqlParameter("@RequestStatus", Total));
                ////command.Parameters.Add(new SqlParameter("@TestReqSerno", Id));
                //////command.Parameters.Add(new SqlParameter("@CreatedDt", DateTime.Now.ToString()));
                /////
                //SqlCommand command = new SqlCommand("Insert into TestMasterT(TestRequestId,TestId,SubTestId,TypeId,InstituteId,PatientId,CreatedDt,CreatedBy,ReceiveDt) values (@TestRequestId,@TestId,@SubTestId,@TypeId,@InstituteId,@PatientId,getdate(),@CreatedBy,getdate()+5);Select Scope_Identity();", con);
                //command.CommandType = System.Data.CommandType.Text;
                //command.Parameters.Add(new SqlParameter("@TestRequestId ", Id));
                //command.Parameters.Add(new SqlParameter("@TestId ", testid));
                //command.Parameters.Add(new SqlParameter("@SubTestId", subtestid));
                //command.Parameters.Add(new SqlParameter("@TypeId", TypeId));
                //if (TypeId == 1)
                //{
                //    command.Parameters.Add(new SqlParameter("@InstituteId", instituteid));
                //    command.Parameters.Add(new SqlParameter("@PatientId", DBNull.Value));
                //}
                //else if (TypeId == 2)
                //{
                //    command.Parameters.Add(new SqlParameter("@InstituteId", DBNull.Value));
                //    command.Parameters.Add(new SqlParameter("@PatientId", instituteid));
                //}
                //else if (TypeId == 3)
                //{
                //    command.Parameters.Add(new SqlParameter("@InstituteId", DBNull.Value));
                //    command.Parameters.Add(new SqlParameter("@PatientId", DBNull.Value));
                //}

                //command.Parameters.Add(new SqlParameter("@CreatedBy", "Fahad Ashraf"));
                ////command.Parameters.Add(new SqlParameter("@CreatedDt", DateTime.Now.ToString()));
                //var values = "";
                //for (int i = 0; i < Total; i++)
                //{
                //    int CompletedTestId = Convert.ToInt32(command.ExecuteScalar());
                //    if (CompletedTestId > 0)
                //        values = values == "" ? CompletedTestId.ToString() : values + "," + CompletedTestId.ToString();
                //}




              

                //command = new SqlCommand();
                //string query = "select * from TestMasterT where TestSerno=" + Id + "";
                //command = new SqlCommand(query, con);

                //List<BarCodeLogs> barcodeWithRelatedData = new List<BarCodeLogs>();

                //using (command = new SqlCommand(query, con))
                //{
                //    using (SqlDataReader reader = command.ExecuteReader())
                //    {
                //        while (reader.Read())
                //        {
                //            BarCodeLogs testMasterT = new BarCodeLogs();
                //            testMasterT.BID = reader["BID"].ToString();
                //            barcodeWithRelatedData.Add(testMasterT);
                            
                //        }
                //    }
                //}

                //con.Dispose();
                //con.Close();
                //con.Dispose();
                //ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn4", "alert('Data Saved Succeessfully')", true);
                //var result = JsonConvert.SerializeObject(barcodeWithRelatedData);
                //string jsFunc = "bindBarcode( '" + result + "')";
                //ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn", jsFunc, true);

            }
            catch (Exception ex)
            {
                string jsFunc = "Alert( '" + ex.Message.ToString() + "')";
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "error", jsFunc, true);
            }
        }

        private void GetPrintBarcode(int Id)
        {
            AppCode.Connection Con = new AppCode.Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            SqlCommand command = new SqlCommand();
            command = new SqlCommand();
            string query = "select * from TestMasterT where TestSerno=" + Id + "";
            command = new SqlCommand(query, con);

            List<BarCodeLogs> barcodeWithRelatedData = new List<BarCodeLogs>();

            using (command = new SqlCommand(query, con))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        BarCodeLogs testMasterT = new BarCodeLogs();
                        testMasterT.BID = reader["BID"].ToString();
                        barcodeWithRelatedData.Add(testMasterT);

                    }
                }
            }

            con.Dispose();
            con.Close();
            con.Dispose();
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn4", "alert('Data Saved Succeessfully')", true);
            var result = JsonConvert.SerializeObject(barcodeWithRelatedData);
            string jsFunc = "bindBarcode( '" + result + "')";
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn", jsFunc, true);
        }

        protected void Confirm_Btn_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
            UpdatePanel2.Update();
            Submit_Btn.Visible = true;
            ModalTestLbl.Text = Testtxt.Text;
            ModalSubTestLbl.Text = SubTesttxt.Text;
            //if (InstituteHidden.Value != null && InstituteHidden.Value == "------")
            //{
            //    location.Visible = false;
            //    ModalInstituteLbl.Visible = false;
            //}
            //else
            //{
            ModalInstituteLbl.Text = InstituteDrp.Text;
            //}
            Total_Lbl.Text = ActualTestTxt.Text;
            Button2.Text = "Close";
        }
    }
}