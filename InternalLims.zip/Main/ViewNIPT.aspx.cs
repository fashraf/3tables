﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class ViewNIPT : System.Web.UI.Page
    {
        AppCode.Repository repo = new AppCode.Repository();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                //Session["HID"] = "1";
                //Session["UserID"] = "1";

                niptid.Value = Request.QueryString["Id"];//Session["NIPTID"].ToString();
                int nid = Convert.ToInt32(niptid.Value);
                report.Src = "../handler/NIPTReport.ashx?Id=" + nid;
                FillUserData(nid);
                //Logger.WriteLog("Add Request page load");
            }
        }

        private void FillUserData(int nid)
        {
            DataTable dt = repo.getNiptDetailById(nid);
            txtBarCode.Text = dt.Rows[0]["BarcodeId"].ToString();
            Lbl.Text = dt.Rows[0]["TestName"].ToString() + ">" + dt.Rows[0]["SubTestName"].ToString();
            txtNationalID.Text = dt.Rows[0]["NationalId"].ToString();
            txtPatientMRN.Text = dt.Rows[0]["PatientMRN"].ToString();
            txtName.Text = dt.Rows[0]["Name"].ToString();
            CreatedLbl.Text = Convert.ToDateTime(dt.Rows[0]["CreatedDt"]).ToString("dd.MMMM.yyyy");

            DobTxt.Text = Convert.ToDateTime(dt.Rows[0]["Dob"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["DobYears"].ToString() + " ) Year/s";
            txtMobile.Text = dt.Rows[0]["Mobile"].ToString();
            CityLbl.Text = dt.Rows[0]["City"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            txtAddress.Text = dt.Rows[0]["Address"].ToString();
            EthnicLbl.Text = dt.Rows[0]["EthnicBackground"].ToString();

            MenstrualPeriodTxt.Text = Convert.ToDateTime(dt.Rows[0]["LastMenstrualPeriodDate"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["LastMenstrualPeriodWeeks"].ToString() + " ) week/s";
            txtAgeOfGestation.Text = dt.Rows[0]["AgeofGestation"].ToString();

            txtMaternalWeight.Text = dt.Rows[0]["MaternalWeight"].ToString();
            MarriageConsanguineousLbl.Text = dt.Rows[0]["MarriageCon"].ToString();
            ModeConceptionLbl.Text = dt.Rows[0]["ModeConception"].ToString();

            HistoryGeneticTestingLbl.Text = dt.Rows[0]["HistoryGenetic"].ToString();
            LatestUltrasoundTxt.Text = Convert.ToDateTime(dt.Rows[0]["LatestUltrasound"]).ToString("dd.MMMM.yyyy");
            txtUltrasoundFindings.Text = dt.Rows[0]["Ultrasoundfindings"].ToString();
            txtFurtherClinicalDetails.Text = dt.Rows[0]["FurtherClinicalDetails"].ToString();


            txtRequestorName.Text = dt.Rows[0]["RequesterName"].ToString();
            txtRequstorEmail.Text = dt.Rows[0]["RequesterEmail"].ToString();
            txtRequestorMobile.Text = dt.Rows[0]["RequesterMobile"].ToString();

            //txtRequstorEmail.Text = dt.Rows[0]["NationalId"].ToString();
            //txtRequestorMobile.Text = dt.Rows[0]["NationalId"].ToString();

            //txtRequestorName.Text = dt.Rows[0]["NationalId"].ToString();
            //txtRequestorMobile.Text = dt.Rows[0]["NationalId"].ToString();

            DataTable Imgdt = repo.geTestAttachment(nid);
            Img_Grid.DataSource = Imgdt;
            Img_Grid.DataBind();
        }

        protected void Img_Grid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
            Response.TransmitFile(Server.MapPath(e.CommandArgument.ToString()));
            Response.End();
        }
    }
}