﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class NIPTView : System.Web.UI.Page
    {
        AppCode.Drop drop = new AppCode.Drop();
        AppCode.Repository repo = new AppCode.Repository();
        AppCode.Ts ts = new AppCode.Ts();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                //Session["HID"] = "1";
                //Session["UserID"] = "1";

                niptid.Value = Request.QueryString["Id"];//Session["NIPTID"].ToString();
                int nid = Convert.ToInt32(niptid.Value);
                report.Src = "../handler/NIPTReport.ashx?Id=" + nid;
                FillUserData(nid);

               
                //Logger.WriteLog("Add Request page load");
            }
        }
        private void FillUserData(int nid)
        {
            //DataTable geStatus = drop.GetTestAutoWorkFlowStatus(nid);
            //drop.FillDropDownList(NiptStatusDrop, geStatus, "Status", "Id");

            Status_Grid.DataSource= repo.GetTestAutoWorkFlowStatus(nid);
            Status_Grid.DataBind();

            CommentGrid.DataSource = repo.getCommentByTestId(nid);
            CommentGrid.DataBind();
            CommentContLbl.Text = CommentGrid.Rows.Count.ToString();

            DataTable dt = repo.getNiptDetailById(nid);
            txtBarCode.Text = dt.Rows[0]["BarcodeId"].ToString();
            Lbl.Text = dt.Rows[0]["TestName"].ToString() + ">" + dt.Rows[0]["SubTestName"].ToString();
            txtNationalID.Text = dt.Rows[0]["NationalId"].ToString();
            txtPatientMRN.Text = dt.Rows[0]["PatientMRN"].ToString();
            txtName.Text = dt.Rows[0]["Name"].ToString();
            CreatedLbl.Text = Convert.ToDateTime(dt.Rows[0]["CreatedDt"]).ToString("dd.MMMM.yyyy");

            DobTxt.Text = Convert.ToDateTime(dt.Rows[0]["Dob"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["DobYears"].ToString() + " ) Year/s";
            txtMobile.Text = dt.Rows[0]["Mobile"].ToString();
            CityLbl.Text = dt.Rows[0]["City"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            txtAddress.Text = dt.Rows[0]["Address"].ToString();
            EthnicLbl.Text = dt.Rows[0]["EthnicBackground"].ToString();

            MenstrualPeriodTxt.Text = Convert.ToDateTime(dt.Rows[0]["LastMenstrualPeriodDate"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["LastMenstrualPeriodWeeks"].ToString() + " ) week/s";
            txtAgeOfGestation.Text = dt.Rows[0]["AgeofGestation"].ToString();

            txtMaternalWeight.Text = dt.Rows[0]["MaternalWeight"].ToString();
            MarriageConsanguineousLbl.Text = dt.Rows[0]["MarriageCon"].ToString();
            ModeConceptionLbl.Text = dt.Rows[0]["ModeConception"].ToString();

            HistoryGeneticTestingLbl.Text = dt.Rows[0]["HistoryGenetic"].ToString();
            LatestUltrasoundTxt.Text = Convert.ToDateTime(dt.Rows[0]["LatestUltrasound"]).ToString("dd.MMMM.yyyy");
            txtUltrasoundFindings.Text = dt.Rows[0]["Ultrasoundfindings"].ToString();
            txtFurtherClinicalDetails.Text = dt.Rows[0]["FurtherClinicalDetails"].ToString();


            txtRequestorName.Text = dt.Rows[0]["RequesterName"].ToString();
            txtRequstorEmail.Text = dt.Rows[0]["RequesterEmail"].ToString();
            txtRequestorMobile.Text = dt.Rows[0]["RequesterMobile"].ToString();

            //NiptStatusDrop.SelectedValue= dt.Rows[0]["StatusId"].ToString();
            StatusRibbon.Text= dt.Rows[0]["TestStatus"].ToString();

            if (StatusRibbon.Text== "Cancled")
            {
                StatusRibbon.CssClass = "alert alert-danger border";
            }
            else
            {
                StatusRibbon.CssClass = "alert alert-primary border";
            }

            //txtRequstorEmail.Text = dt.Rows[0]["NationalId"].ToString();
            //txtRequestorMobile.Text = dt.Rows[0]["NationalId"].ToString();

            //txtRequestorName.Text = dt.Rows[0]["NationalId"].ToString();
            //txtRequestorMobile.Text = dt.Rows[0]["NationalId"].ToString();

            DataTable Imgdt = repo.geTestAttachment(nid);
            Img_Grid.DataSource = Imgdt;
            Img_Grid.DataBind();


            DataTable TimeLine = repo.getTimelineByTestId(nid, 1);
            TimelineRpt.DataSource = TimeLine;
            TimelineRpt.DataBind();
            
        }

        protected void Img_Grid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
            Response.TransmitFile(Server.MapPath(e.CommandArgument.ToString()));
            Response.End();
        }
        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            int TestSerno = Convert.ToInt32(Request.QueryString["Id"]);
            string UpdatedUserName = "Fahad Ashraf";
            //int StatusId = Convert.ToInt32(NiptStatusDrop.SelectedValue);
            int StatusId = Convert.ToInt32(Status_hdn.Value);
            
            bool UpdateUserInfo = repo.UpdateTestRequestStatus(TestSerno, StatusId, 0, UpdatedUserName);
            repo.InsertTimelineForTest(TestSerno, StatusId, UpdatedUserName, "", "");


            //ScriptManager.RegisterStartupScript(this, this.GetType(), "HidePopup", "$('#Confirm').modal('hide')", true);

         

           string barcode = txtBarCode.Text;
            string novomsg = "NIPT Request with Barcode  </br><strong>" + barcode + "</strong>  has been updated to "+ Status_Name.Value;
            AppCode.SNotiNovo.SendNotiToNovo(2, barcode, novomsg);

            string toastmsg = "Test Status Updated.";
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + toastmsg + "')", true);
            FillUserData(TestSerno);

            int InstituteId = Convert.ToInt32(1);
            AppCode.notification.SaveNotification(InstituteId, 0, StatusId, novomsg, false);

            Control c = this.Master.FindControl("noti");
            c.DataBind();
            
        }

        protected void Status_Grid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Status_hdn.Value = "";
            Status_Name.Value = "";
            if (e.CommandName == "Status")
            {
                GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                string Status = (row.FindControl("Status_Lnk") as Button).Text;
                string statusid= (row.FindControl("status_lbl") as Label).Text;
                Status_hdn.Value = statusid;
                Status_Name.Value = Status;
                Confirm_Header_Lbl.Text = "Confirm !";
                Confirm_Middle_Lbl.Text = "Are you sure you want to Change the Status to </br><strong>" + Status + "</strong></br> for this NIPT Test ?";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
                UpdatePanel2.Update();
            }
           else if (e.CommandName == "No")
            {
                Status_Name.Value = "Cancel";
                GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                string Status = (row.FindControl("Status_Lnk") as Button).Text;
                Status_hdn.Value = "6";
                Confirm_Header_Lbl.Text = "Confirm !";
                Confirm_Middle_Lbl.Text = "Are you sure you want to <strong>Cancel</strong> this Test?";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
                UpdatePanel2.Update();
            }
        }

        protected void TimelineRpt_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Reference the Repeater Item.
                RepeaterItem item = e.Item;
                //Reference the Controls.
                Label dt_txt = (Label)e.Item.FindControl("dt_txt");
                Label serLbl = (Label)e.Item.FindControl("serLbl");
                if (dt_txt.Text == "")
                {
                    serLbl.CssClass = "btn btn-soft-primary";
                }
                else
                {
                    serLbl.CssClass = "btn btn-soft-success";
                    DateTime dt = Convert.ToDateTime(dt_txt.Text);
                    dt_txt.Text = ts.TwoTime(dt);
                }
            }
        }

        protected void Cancle_Lnk_Click(object sender, EventArgs e)
        {
            string Id = Request.QueryString["Id"];
            Response.Redirect("CancelTest.aspx?Id=" + Id + "");
        }

        protected void SubmitComment_Click(object sender, EventArgs e)
        {
            int TestSerno = Convert.ToInt32(Request.QueryString["Id"]);
            string Comment = CommentTxt.Text.Trim();

            int CreatedId = Convert.ToInt32(1);
            string CreatedBy= "Fahad Ashraf";

            bool AddNeComment = repo.InsertComment(TestSerno, Comment,CreatedId, CreatedBy);
            if(AddNeComment==true)
            {
                CommentTxt.Text = string.Empty;
                FillUserData(TestSerno);
                string toastmsg = "Comment Added Successfully";
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + toastmsg + "')", true);
            }
            //repo.InsertTimelineForTest(TestSerno, StatusId, UpdatedUserName, "", "");


            //ScriptManager.RegisterStartupScript(this, this.GetType(), "HidePopup", "$('#Confirm').modal('hide')", true);



            string barcode = txtBarCode.Text;
            string novomsg = "NIPT Request with Barcode  </br><strong>" + barcode + "</strong>  has been updated to " + Status_Name.Value;
        }
    }
}