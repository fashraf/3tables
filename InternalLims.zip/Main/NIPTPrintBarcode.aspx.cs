﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static InternalLims.AppCode.dto;

namespace InternalLims.Main
{
    public partial class NIPTPrintBarcode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPatentGrid();
            }
        }

        private void LoadPatentGrid()
        {
            gvPrint.DataSource = GetData("SELECT TestMasterT.TestRequestId,CASE WHEN NiPtMaster.BarcodeId IS NULL THEN TestMasterT.BID + '--Not Used' ELSE NiPtMaster.BarcodeId END AS 'Barcode',NiPtMaster.TestId, TestMasterL.TestName + ' -' + SubTestMasterL.SubTestName AS TestName, TestMasterT.BID BarcodeId,REPLACE(CONCAT( PatientMaster.FirstName+' ',PatientMaster.MiddleName+' ',PatientMaster.LastName+' '),'  ',' ') PatName, NiPtMaster.CreatedDt AS CreatedDt, TestMasterT.InstituteId, InstituteMasterL.InstituteName,CityMasterL.City, TestStatusMasterL.TestStatus FROM TestStatusMasterL INNER JOIN PatientMaster INNER JOIN NiPtMaster ON PatientMaster.PatientSerno = NiPtMaster.PatId ON TestStatusMasterL.TestStatusSerno = NiPtMaster.NIPTStatus RIGHT OUTER JOIN TestMasterL INNER JOIN TestMasterT ON TestMasterL.TestMasterSerno = TestMasterT.TestId INNER JOIN SubTestMasterL ON TestMasterT.SubTestId = SubTestMasterL.SubTestMasterSerno INNER JOIN InstituteMasterL ON TestMasterT.InstituteId = InstituteMasterL.InstituteSerno INNER JOIN CityMasterL ON InstituteMasterL.CityId = CityMasterL.CitySerno ON NiPtMaster.TestId = TestMasterT.TestSerno");
            gvPrint.DataBind();
        }

        private static DataTable GetData(string query)
        {
            string strConnString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataSet ds = new DataSet())
                        {
                            DataTable dt = new DataTable();
                            sda.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
        }
      
        protected void Me_Link_Click(object sender, EventArgs e)
        {
            string MEID = (sender as LinkButton).CommandArgument;
            Session["MEID"] = MEID.ToString();
            Response.Redirect("Me_Detail.aspx");
        }

        protected void gvChild_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }

        protected void PrintB_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label BarcodeLbl = (Label)row.FindControl("BarcodeLbl");
            Label CreatedDt = (Label)row.FindControl("CreatedDt");
            Label patName = (Label)row.FindControl("patName");
            Label RecievedDate = (Label)row.FindControl("CreatedDt");

            List<TestMasterT> barcodeWithRelatedData = new List<TestMasterT>();

            TestMasterT testMasterT = new TestMasterT();
            testMasterT.BID = BarcodeLbl.Text;
            if (CreatedDt.Text == "")
            {
                
            }
            else
            {
                testMasterT.CreatedDt = Convert.ToDateTime(CreatedDt.Text);
                testMasterT.PatName = patName.Text;
                testMasterT.ReceiveDt = Convert.ToDateTime(RecievedDate.Text);
            }
            barcodeWithRelatedData.Add(testMasterT);

            var result = JsonConvert.SerializeObject(barcodeWithRelatedData);
            string jsFunc = "bindBarcode( '" + result + "')";
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "myJsFn", jsFunc, true);

            Page.ClientScript.RegisterStartupScript(Page.GetType(), "mykey", "print();", true);
        }

        protected void gvPrint_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string TestRequestId = gvPrint.DataKeys[e.Row.RowIndex].Value.ToString();
                Label CreatedDt = e.Row.FindControl("CreatedDt") as Label;
                Button PrintName = e.Row.FindControl("PrintName") as Button;
                if (CreatedDt.Text == "")
                {
                    PrintName.Visible = false;
                }
            }
        }

        protected void gvPrint_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvPrint.PageIndex = e.NewPageIndex;
            LoadPatentGrid();
        }

        //protected void gvChild_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    GridView gvChild = (GridView)sender;
        //    gvChild.PageIndex = e.NewPageIndex;
        //    gvChild.DataSource = GetData(string.Format("SELECT TestMasterT.TestRequestId,case when NiPtMaster.BarcodeId is null then 'Not Used' else NiPtMaster.BarcodeId end 'Barcode',NiPtMaster.CreatedDt  FROM TestMasterT LEFT JOIN NiPtMaster ON TestMasterT.BID = NiPtMaster.BarcodeId where TestMasterT.TestRequestId='{0}'", TestRequestId));
        //    gvChild.DataBind();
        //}
    }
}