﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternalLims.Main
{
    public partial class CancelTest : System.Web.UI.Page
    {
        AppCode.Drop drop = new AppCode.Drop();
        AppCode.Repository repo = new AppCode.Repository();
        AppCode.Ts ts = new AppCode.Ts();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                //Session["HID"] = "1";
                //Session["UserID"] = "1";

                niptid.Value = Request.QueryString["Id"];//Session["NIPTID"].ToString();
                int nid = Convert.ToInt32(niptid.Value);
                report.Src = "../handler/NIPTReport.ashx?Id=" + nid;
                FillUserData(nid);


                //Logger.WriteLog("Add Request page load");
            }
        }
        private void FillUserData(int nid)
        {
            //DataTable geStatus = drop.GetTestAutoWorkFlowStatus(nid);
            //drop.FillDropDownList(NiptStatusDrop, geStatus, "Status", "Id");

            DataTable dt = repo.getNiptDetailById(nid);
            txtBarCode.Text = dt.Rows[0]["BarcodeId"].ToString();
            Lbl.Text = dt.Rows[0]["TestName"].ToString() + ">" + dt.Rows[0]["SubTestName"].ToString();
            txtNationalID.Text = dt.Rows[0]["NationalId"].ToString();
            txtPatientMRN.Text = dt.Rows[0]["PatientMRN"].ToString();
            txtName.Text = dt.Rows[0]["Name"].ToString();
            CreatedLbl.Text = Convert.ToDateTime(dt.Rows[0]["CreatedDt"]).ToString("dd.MMMM.yyyy");

            DobTxt.Text = Convert.ToDateTime(dt.Rows[0]["Dob"]).ToString("dd.MMMM.yyyy") + " ( " + dt.Rows[0]["DobYears"].ToString() + " ) Year/s";
            txtMobile.Text = dt.Rows[0]["Mobile"].ToString();
            CityLbl.Text = dt.Rows[0]["City"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            txtAddress.Text = dt.Rows[0]["Address"].ToString();
            EthnicLbl.Text = dt.Rows[0]["EthnicBackground"].ToString();

            //NiptStatusDrop.SelectedValue= dt.Rows[0]["StatusId"].ToString();
            StatusRibbon.Text = dt.Rows[0]["TestStatus"].ToString();

            if (StatusRibbon.Text == "Cancled")
            {
                StatusRibbon.CssClass = "alert alert-danger border";
            }
            else
            {
                StatusRibbon.CssClass = "alert alert-primary border";
            }
            txtRequestorName.Text = dt.Rows[0]["RequesterName"].ToString();
            txtRequstorEmail.Text = dt.Rows[0]["RequesterEmail"].ToString();
            txtRequestorMobile.Text = dt.Rows[0]["RequesterMobile"].ToString();


            CurrentStatusLbl.Text = StatusRibbon.Text;

            DataTable Imgdt = repo.geTestAttachment(nid);
            Img_Grid.DataSource = Imgdt;
            Img_Grid.DataBind();


            DataTable TimeLine = repo.getTimelineByTestId(nid, 1);
            TimelineRpt.DataSource = TimeLine;
            TimelineRpt.DataBind();

        }

        protected void Img_Grid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
            Response.TransmitFile(Server.MapPath(e.CommandArgument.ToString()));
            Response.End();
        }

        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            int TestSerno = Convert.ToInt32(Request.QueryString["Id"]);
            string UpdatedUserName = "Fahad Ashraf";
            //int StatusId = Convert.ToInt32(NiptStatusDrop.SelectedValue);
            int StatusId = Convert.ToInt32(Status_hdn.Value);
            string Reason = CancelTxt.Text;
            bool UpdateUserInfo = repo.UpdateTestRequestStatus(TestSerno, StatusId, 0, UpdatedUserName);
            repo.InsertTimelineForTest(TestSerno, StatusId, UpdatedUserName, "", Reason);

            string barcode = txtBarCode.Text;
            string novomsg = "NIPT Request with Barcode  </br><strong>" + barcode + "</strong>  has been Canceled";
            AppCode.SNotiNovo.SendNotiToNovo(2, barcode, novomsg);

            string toastmsg = "Test Status Canceled.";
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "launch_toast('" + toastmsg + "')", true);
            FillUserData(TestSerno);

        }

        protected void TimelineRpt_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Reference the Repeater Item.
                RepeaterItem item = e.Item;
                //Reference the Controls.
                Label dt_txt = (Label)e.Item.FindControl("dt_txt");
                Label serLbl = (Label)e.Item.FindControl("serLbl");
                if (dt_txt.Text == "")
                {
                    serLbl.CssClass = "btn btn-soft-primary";
                }
                else
                {
                    serLbl.CssClass = "btn btn-soft-success";
                    DateTime dt = Convert.ToDateTime(dt_txt.Text);
                    dt_txt.Text = ts.TwoTime(dt);
                }
            }
        }

        protected void Cancle_Lnk_Click(object sender, EventArgs e)
        {
            Status_Name.Value = "Cancel";
            Status_hdn.Value = "6";
            Confirm_Header_Lbl.Text = "Confirm !";
            Confirm_Middle_Lbl.Text = "Are you sure you want to <strong>Cancel</strong> this Test?";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "none", "<script>$('#Confirm').modal('show');</script>", false);
            UpdatePanel2.Update();
        }
    }
}