﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InternalLims.handler
{
    /// <summary>
    /// Summary description for NewTestList
    /// </summary>
    public class NewTestList : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            List<AppCode.dto.TestRegistrationList> dataList = new List<AppCode.dto.TestRegistrationList>();
            dataList = AppCode.ListData.getNewTestRequestList();
            context.Response.Write(JsonConvert.SerializeObject(dataList));
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}