﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace InternalLims.AppCode
{
    public class Audit
    {
        public bool auditlog(int hid, int uid, string username, int cat, string meta, int usertype, bool showhide)
        {
            Connection Con = new Connection();
            String Connection = Con.NovoAdmin();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string IP = GetLocalIPAddress();
            SqlCommand command = new SqlCommand("insert into auditmaster(hid,uid,username,cat,meta,usertype,showhide,ip,dt) values(@hid,@uid,@username,@cat,@meta,@usertype,@showhide,@ip,@dt)", con);
            command.CommandType = System.Data.CommandType.Text;
            command.Parameters.Add(new SqlParameter("@hid", hid));
            command.Parameters.Add(new SqlParameter("@uid", uid));
            command.Parameters.Add(new SqlParameter("@username", username));
            command.Parameters.Add(new SqlParameter("@cat", cat));
            command.Parameters.Add(new SqlParameter("@meta", meta));
            command.Parameters.Add(new SqlParameter("@usertype", usertype));
            command.Parameters.Add(new SqlParameter("@showhide", showhide));
            command.Parameters.Add(new SqlParameter("@ip", IP));
            command.Parameters.Add(new SqlParameter("@dt", DateTime.Now.ToString()));
            if (command.ExecuteNonQuery() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            con.Dispose();
            con.Close();
            con.Dispose();
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("IP not found!");
        }
    }
}