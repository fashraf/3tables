﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace InternalLims.AppCode
{
    public class Dashboard
    {
        public DataTable getNiptDetail()
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT COUNT(NIPTSerno) as 'TotalNIPT',COUNT(CASE WHEN niptstatus = 1 then 1 ELSE NULL END) as 'Submitted',COUNT(CASE WHEN niptstatus = 4 then 1 ELSE NULL END) as 'Recieved',COUNT(CASE WHEN niptstatus in (2009,2010) then 1 ELSE NULL END) as 'InLab',	COUNT(CASE WHEN niptstatus =2011 then 1 ELSE NULL END) as 'MovedtoMachine' from niptmaster", con);
            command.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }

        public DataTable getRegisteredUserDetail()
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT COUNT(UserAccStatus) as 'TotalUsers',COUNT(CASE WHEN UserAccStatus = 9 then 1 ELSE NULL END) as 'NewUserRegistration',COUNT(CASE WHEN UserAccStatus = 10 then 1 ELSE NULL END) as 'UserActive',COUNT(CASE WHEN UserAccStatus =11 then 1 ELSE NULL END) as 'UserInactive' from usermaster", con);
            command.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }
    }
}