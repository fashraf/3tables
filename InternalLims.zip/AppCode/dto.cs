﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InternalLims.AppCode
{
    public class dto
    {
        public class InstituteInformation
        {
            public int ID { get; set; }
            public string instituteName { get; set; }
            public string instituteCity { get; set; }
            public string instituteType { get; set; }
            public string instituteOwnership { get; set; }
            public string UserName { get; set; }
            public string UserMobile { get; set; }
            public string CreatedDate { get; set; }
            public string instituteStatus { get; set; }
            public int SelectedVal { get; set; }
        }

        public class NewUserRegistration
        {
            public int UserID { get; set; }
            public string UserTitle { get; set; }
            public string UserFullName { get; set; }
            public string UserMobile { get; set; }
            public string UserEmail { get; set; }
            public string InstituteName { get; set; }
            public string InstituteCity { get; set; }
            public string CreatedDate { get; set; }
            public string UserStatus { get; set; }
        }


        public class TestRegistrationList
        {
            public int TestSerno { get; set; }
            public int TestId { get; set; }
            public string Barcode { get; set; }
            public string TestName { get; set; }
            public string SubTestName { get; set; }
            public string InstituteName { get; set; }
            public string NationalId { get; set; }
            public string PatientMRN { get; set; }
            public string Name { get; set; }
            public string Mobile { get; set; }
            public string CreatedDt { get; set; }
            public string TestStatus { get; set; }
        }


        public class TestKitsRequestList
        {
            public int RequestId { get; set; }
            public int TestId { get; set; }
            public string TestName { get; set; }
            public int SubTestId { get; set; }
            public string SubTestName { get; set; }
            public string InstituteId { get; set; }
            public string InstituteName { get; set; }
            public string City { get; set; }
            public int RequestedTest { get; set; }
            public string ActualTest { get; set; }
            public string Status { get; set; }
            public string CreatedDt { get; set; }
            public string Barcode { get; set; }
        }
        public class BarCodeLogs
        {
            public int? Id { get; set; }
            public int TestSemo { get; set; }
            public string BID { get; set; }
            public string ErrorMesssage { get; set; }
            public string IPAddress { get; set; }
        }

        public class TestMasterT
        {
            public int? TestId { get; set; }
            public int? TestSerno { get; set; }
            public int? SubTestId { get; set; }
            public int? TypeId { get; set; }
            public int? InstituteId { get; set; }
            public string BID { get; set; }
            public string PatName { get; set; }
            public DateTime CreatedDt { get; set; }
            public string CreatedBy { get; set; }
            public DateTime ReceiveDt { get; set; }
        }

        public class InstituteBarList
        {
            public int? TestId { get; set; }
            public string BID { get; set; }
            public string InstituteName { get; set; }
            public string TestName { get; set; }
            public string SubTestName { get; set; }
            public string CompletedStatus { get; set; }
            public string CreatedDt { get; set; }
          
        }
    }
}