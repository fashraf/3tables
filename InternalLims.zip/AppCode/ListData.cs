﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace InternalLims.AppCode
{
    public class ListData
    {
        public static List<dto.InstituteInformation> getInstituteList()
        {
            List<dto.InstituteInformation> list = new List<dto.InstituteInformation>();
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string query = "getInstituteList";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.CommandType = CommandType.StoredProcedure;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dto.InstituteInformation d = new dto.InstituteInformation();
                        d.ID = Convert.ToInt32(reader["Id"]);
                        d.instituteName = Convert.ToString(reader["InstituteName"]);
                        d.instituteCity = Convert.ToString(reader["City"]);
                        d.instituteType = Convert.ToString(reader["InstituteType"]);
                        d.instituteOwnership = Convert.ToString(reader["Ownership"]);
                        d.UserName = Convert.ToString(reader["UserName"]);
                        d.UserMobile = Convert.ToString(reader["Mobile"]);
                        d.instituteStatus = Convert.ToDateTime(reader["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt");//Convert.ToString(reader["CreatedDt"]);
                        d.CreatedDate = "Active";
                        list.Add(d);
                    }
                }
                con.Close();
            }
            return list;
        }


        public static List<dto.NewUserRegistration> getNewRegisterationUserList()
        {
            //////User Status=1
            List<dto.NewUserRegistration> list = new List<dto.NewUserRegistration>();
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string query = "SELECT UserMaster.UserSerNo AS UserId, UserTitleMasterL.UserTitle, UserMaster.UserFullName, UserMaster.Email, UserMaster.Mobile, InstituteMasterL.InstituteName, CityMasterL.City, UserMaster.CreatedDt,TestStatusMasterL.TestStatus UserAccStatus FROM UserMaster INNER JOIN InstituteMasterL ON UserMaster.InstituteId = InstituteMasterL.InstituteSerno INNER JOIN CityMasterL ON InstituteMasterL.CityId = CityMasterL.CitySerno INNER JOIN UserTitleMasterL ON UserMaster.UserTitleId = UserTitleMasterL.UserTitleSerno INNER JOIN TestStatusMasterL ON UserMaster.UserAccStatus = TestStatusMasterL.TestStatusSerno WHERE  (UserMaster.UserAccStatus in (9,10,11))";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.CommandType = CommandType.Text;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dto.NewUserRegistration d = new dto.NewUserRegistration();
                        d.UserID = Convert.ToInt32(reader["UserId"]);
                        d.InstituteName = Convert.ToString(reader["InstituteName"]);
                        d.InstituteCity= Convert.ToString(reader["City"]);
                        d.UserTitle = Convert.ToString(reader["UserTitle"]);
                        d.UserFullName= Convert.ToString(reader["UserFullName"]);
                        d.UserMobile = Convert.ToString(reader["Mobile"]);
                        d.UserEmail = Convert.ToString(reader["Email"]);
                        d.UserStatus = Convert.ToString(reader["UserAccStatus"]);
                        d.CreatedDate = Convert.ToDateTime(reader["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt");//Convert.ToString(reader["CreatedDt"]);
                        list.Add(d);
                    }
                }
                con.Close();
            }
            return list;
        }








        #region

        public static List<dto.TestRegistrationList> getNewTestRequestList()
        {
            List<dto.TestRegistrationList> list = new List<dto.TestRegistrationList>();
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string query = "SELECT TestMasterT.TestSerno TestSerno,NiPtMaster.NIPTSerno AS TestId, TestMasterT.BID AS Barcode, TestMasterL.TestName, SubTestMasterL.SubTestName, NiPtMaster.NationalId, NiPtMaster.PatientMRN, NiPtMaster.Name, NiPtMaster.Mobile,NiPtMaster.CreatedDt, TestStatusMasterL.TestStatus FROM TestMasterT INNER JOIN NiPtMaster ON TestMasterT.BID = NiPtMaster.BarcodeId INNER JOIN TestMasterL ON TestMasterT.TestId = TestMasterL.TestMasterSerno INNER JOIN SubTestMasterL ON TestMasterT.SubTestId = SubTestMasterL.SubTestMasterSerno INNER JOIN TestStatusMasterL ON NiPtMaster.NIPTStatus = TestStatusMasterL.TestStatusSerno where TestStatusMasterL.TestStatusSerno=1";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.CommandType = CommandType.Text;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dto.TestRegistrationList d = new dto.TestRegistrationList();
                        d.TestSerno = Convert.ToInt32(reader["TestSerno"]);
                        d.TestId = Convert.ToInt32(reader["TestId"]);
                        d.Barcode = Convert.ToString(reader["Barcode"]);
                        d.TestName = Convert.ToString(reader["TestName"]);
                        d.SubTestName = Convert.ToString(reader["SubTestName"]);
                        //d.InstituteName = Convert.ToString(reader["InstituteName"]);
                        d.Name = Convert.ToString(reader["Name"]);
                        d.NationalId = Convert.ToString(reader["NationalId"]);
                        d.Mobile = Convert.ToString(reader["Mobile"]);
                        d.CreatedDt = Convert.ToDateTime(reader["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt");//Convert.ToString(reader["CreatedDt"]);
                        d.TestStatus = Convert.ToString(reader["TestStatus"]);
                        list.Add(d);
                    }
                }
                con.Close();
            }
            return list;
        }

        public static List<dto.TestRegistrationList> getTestRequestList()
        {
            List<dto.TestRegistrationList> list = new List<dto.TestRegistrationList>();
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string query = "SELECT DISTINCT NiPtMaster.TestId AS TestId, TestMasterT.BID AS Barcode, TestMasterL.TestName, SubTestMasterL.SubTestName, NiPtMaster.NationalId, NiPtMaster.PatientMRN, NiPtMaster.Name, NiPtMaster.Mobile,NiPtMaster.CreatedDt, TestStatusMasterL.TestStatus FROM TestMasterT INNER JOIN NiPtMaster ON TestMasterT.BID = NiPtMaster.BarcodeId INNER JOIN TestMasterL ON TestMasterT.TestId = TestMasterL.TestMasterSerno INNER JOIN SubTestMasterL ON TestMasterT.SubTestId = SubTestMasterL.SubTestMasterSerno INNER JOIN TestStatusMasterL ON NiPtMaster.NIPTStatus = TestStatusMasterL.TestStatusSerno ";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.CommandType = CommandType.Text;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dto.TestRegistrationList d = new dto.TestRegistrationList();
                        d.TestId = Convert.ToInt32(reader["TestId"]);
                        d.Barcode = Convert.ToString(reader["Barcode"]);
                        d.TestName = Convert.ToString(reader["TestName"]);
                        d.SubTestName= Convert.ToString(reader["SubTestName"]);
                        //d.InstituteName = Convert.ToString(reader["InstituteName"]);
                        d.Name = Convert.ToString(reader["Name"]);
                        d.NationalId = Convert.ToString(reader["NationalId"]);
                        d.Mobile = Convert.ToString(reader["Mobile"]);
                        d.CreatedDt = Convert.ToDateTime(reader["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt");//Convert.ToString(reader["CreatedDt"]);
                        d.TestStatus = Convert.ToString(reader["TestStatus"]);
                        list.Add(d);
                    }
                }
                con.Close();
            }
            return list;
        }

        #endregion


        public static List<dto.TestKitsRequestList> getTestKitRequestList()
        {
            List<dto.TestKitsRequestList> list = new List<dto.TestKitsRequestList>();
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string query = "SELECT TestRequestMasterT.TestReqSerno RequestId,TestRequestMasterT.TestId, TestMasterL.TestName, SubTestMasterL.SubTestMasterSerno SubTestId, SubTestMasterL.SubTestName,TestRequestMasterT.TestRequest,case when TestRequestMasterT.ActualRequest is null then CONVERT(varchar(100), '---') else CONVERT(varchar(100), TestRequestMasterT.ActualRequest) end ActualRequest , TestRequestMasterT.InstituteId, InstituteMasterL.InstituteName, CityMasterL.City,TestStatusMasterL.TestStatus,TestRequestMasterT.CreatedDt FROM TestMasterL INNER JOIN TestRequestMasterT ON TestMasterL.TestMasterSerno = TestRequestMasterT.TestId INNER JOIN SubTestMasterL ON TestRequestMasterT.SubTestId = SubTestMasterL.SubTestMasterSerno INNER JOIN InstituteMasterL ON TestRequestMasterT.InstituteId = InstituteMasterL.InstituteSerno INNER JOIN CityMasterL ON InstituteMasterL.CityId = CityMasterL.CitySerno INNER JOIN TestStatusMasterL ON TestRequestMasterT.RequestStatus = TestStatusMasterL.TestStatusSerno";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.CommandType = CommandType.Text;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dto.TestKitsRequestList d = new dto.TestKitsRequestList();
                        d.RequestId = Convert.ToInt32(reader["RequestId"]);
                        d.TestId = Convert.ToInt32(reader["TestId"]);
                        d.TestName = Convert.ToString(reader["TestName"]);
                        d.SubTestId = Convert.ToInt32(reader["SubTestId"]);
                        d.SubTestName = Convert.ToString(reader["SubTestName"]);
                        d.RequestedTest = Convert.ToInt32(reader["TestRequest"]);
                        d.ActualTest = Convert.ToString(reader["ActualRequest"]);
                        d.InstituteName = Convert.ToString(reader["InstituteName"]);
                        d.City = Convert.ToString(reader["City"]);
                        d.Status = Convert.ToString(reader["TestStatus"]);
                        d.CreatedDt = Convert.ToDateTime(reader["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt");
                        list.Add(d);
                    }
                }
                con.Close();
            }
            return list;
        }


        public static List<dto.InstituteBarList> getInstituteBarcodeList()
        {
            List<dto.InstituteBarList> list = new List<dto.InstituteBarList>();
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            string query = "SELECT distinct TestMasterT.TestSerno 'TestId',TestMasterT.BID,InstituteMasterL.InstituteName,TestMasterL.TestMasterSerno TestId,TestMasterL.TestName,SubTestMasterL.TestCodeId SubtestId,SubTestMasterL.SubTestName, TestMasterT.TestId, TestMasterT.SubTestId,case when TestMasterT.Completed=1 then 'Completed' else 'Available' end CompletedStatus,TestMasterT.Completed,TestMasterT.CreatedDt FROM  TestMasterT inner JOIN InstituteMasterL ON TestMasterT.InstituteId = InstituteMasterL.InstituteSerno INNER JOIN TestMasterL ON TestMasterT.TestId = TestMasterL.TestMasterSerno INNER JOIN SubTestMasterL ON TestMasterT.SubTestId = SubTestMasterL.SubTestMasterSerno";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.CommandType = CommandType.Text;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dto.InstituteBarList d = new dto.InstituteBarList();
                        d.TestId = Convert.ToInt32(reader["TestId"]);
                        d.BID = Convert.ToString(reader["BID"]);
                        d.InstituteName = Convert.ToString(reader["InstituteName"]);
                        
                        d.TestName = Convert.ToString(reader["TestName"]);
                        d.SubTestName = Convert.ToString(reader["SubTestName"]);
                        d.CompletedStatus = Convert.ToString(reader["CompletedStatus"]);
                        d.CreatedDt= Convert.ToDateTime(reader["CreatedDt"]).ToString("dd.MMM.yyyy hh:mm tt");//Convert.ToString(reader["CreatedDt"]);
                        list.Add(d);
                    }
                }
                con.Close();
            }
            return list;
        }
    }
}