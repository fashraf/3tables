﻿namespace InternalLims.AppCode
{


    partial class NIPTRDataset
    {
    }
}
