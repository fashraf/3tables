﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace InternalLims.AppCode
{
    public class Drop
    {
        public DropDownList FillDropDownList(DropDownList dropdownlist, DataTable dt, string datatext, string datavalue)
        {
            if (dt.Rows.Count > 0)
            {
                dropdownlist.DataSource = dt;
                dropdownlist.DataTextField = datatext;
                dropdownlist.DataValueField = datavalue;
                dropdownlist.DataBind();
                dropdownlist.Items.Insert(0, new ListItem("------", "-1"));
            }
            else if (dt.Rows.Count == 0)
            {
                dropdownlist.Items.Clear();
            }
            return dropdownlist;
        }

        public RadioButtonList FillRadioList(RadioButtonList Radiolist, DataTable dt, string datatext, string datavalue)
        {
            if (dt.Rows.Count > 0)
            {
                Radiolist.DataSource = dt;
                Radiolist.DataTextField = datatext;
                Radiolist.DataValueField = datavalue;
                Radiolist.DataBind();
            }
            else if (dt.Rows.Count == 0)
            {
                Radiolist.Items.Clear();
            }
            return Radiolist;
        }

        public DataTable GetUserStatus()
        {
            ////in TestStatusMasterL where TestStatusType=2
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = new SqlCommand();
            command = new SqlCommand("select TestStatusSerno Id,TestStatus Status from TestStatusMasterL where TestStatusType =2 order by TestStatusType asc", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            // Populate a Table with the rows returned. 
            adapter.SelectCommand = command;
            adapter.Fill(results);
            // Dispose resources used. 
            adapter.Dispose();
            command.Dispose();
            return results;
        }

        public DataTable GetRecievedSpecificStatus()
        {
            ////in TestStatusMasterL where TestStatusType=2
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = new SqlCommand();
            command = new SqlCommand("select TestStatusSerno Id,TestStatus Status from TestStatusMasterL where TestStatusSerno in(3,8,1009) order by TestStatusType asc", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            // Populate a Table with the rows returned. 
            adapter.SelectCommand = command;
            adapter.Fill(results);
            // Dispose resources used. 
            adapter.Dispose();
            command.Dispose();
            return results;
        }

        public DataTable GetRejectReason()
        {
            ////in TestStatusMasterL where TestStatusType=2
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = new SqlCommand();
            command = new SqlCommand("select RejectSerno Id,RejectReason RejectReason from RejectMasterL", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            // Populate a Table with the rows returned. 
            adapter.SelectCommand = command;
            adapter.Fill(results);
            // Dispose resources used. 
            adapter.Dispose();
            command.Dispose();
            return results;
        }

        public DataTable GetTestStatus()
        {
            ////in TestStatusMasterL where TestStatusType=2
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = new SqlCommand();
            command = new SqlCommand("select TestStatusSerno Id,TestStatus Status from TestStatusMasterL where TestStatusType =1 order by TestStatusType asc", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            // Populate a Table with the rows returned. 
            adapter.SelectCommand = command;
            adapter.Fill(results);
            // Dispose resources used. 
            adapter.Dispose();
            command.Dispose();
            return results;
        }

        public DataTable GetTestAutoWorkFlowStatus(int TestId)
        {
            ////in TestStatusMasterL where TestStatusType=2
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = new SqlCommand();
            command = new SqlCommand("SELECT top 1 TestStatusMasterL.TestStatusSerno Id,TestStatusMasterL.TestStatus Status FROM TestStepMasterL INNER JOIN TestStatusMasterL ON TestStepMasterL.statusid = TestStatusMasterL.TestStatusSerno where TestStepMasterL.statusid > (SELECT NIPTStatus  FROM NiPtMaster where NiPtMaster.NIPTSerno = @Id) order by TestStepMasterL.stepnumber asc", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            command.Parameters.Add(new SqlParameter("@Id ", TestId));
            // Populate a Table with the rows returned. 
            adapter.SelectCommand = command;
            adapter.Fill(results);
            // Dispose resources used. 
            adapter.Dispose();
            command.Dispose();
            return results;
        }


        #region CraeateBarcode
        public DataTable GetTestList()
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT TestMasterSerno Id,TestName FROM TestMasterL", con);
            command.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }

        public DataTable GetSubTestListOnly()
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT SubTestMasterSerno Id,SubTestName FROM SubTestMasterL", con);
            command.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }

        public DataTable GetSubTestList(int TestId)
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT SubTestMasterSerno Id,SubTestName FROM SubTestMasterL where TestCodeId=@TestId", con);
            command.CommandType = CommandType.Text;
            command.Parameters.Add(new SqlParameter("@TestId", TestId));
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }

        public DataTable GetInstituteList()
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT InstituteSerno Id,InstituteName Name FROM InstituteMasterL", con);
            command.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }
        public DataTable GetPatientList()
        {
            Connection Con = new Connection();
            String Connection = Con.Con();
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            DataTable results = new DataTable();
            SqlCommand command = null;
            command = new SqlCommand("SELECT PatientSerno Id,FirstName Name FROM PatientMaster", con);
            command.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(results);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            con.Dispose();
            return results;
        }
        #endregion
    }
}